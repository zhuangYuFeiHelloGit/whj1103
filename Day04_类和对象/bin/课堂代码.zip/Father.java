
public class Father {
	String name = "小头爸爸";
	int age = 18;
	double salary = 10000000.0;
	
	
	public void showInfo(){
		System.out.println("名字:"+name+" 年龄:"+age+" 工资"+salary);
	}
	
	
}
