package dao.util;

import java.sql.Connection;

/**
 * Created by zyf on 2017/12/14.
 */
public interface JdbcInter {
	void conn(Connection conn);
}
