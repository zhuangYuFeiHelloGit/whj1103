package util;

/**
 * Created by zyf on 2017/12/13.
 */
public class Constants {
	public static final String DEMO = "http://localhost:8080/day16/insert?username=zhangSan&score=1";
}
