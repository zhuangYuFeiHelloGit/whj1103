import org.junit.Test;

import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

/**
 * Created by zyf on 2017/12/13.
 */
public class T {
	@Test
	public void t() throws Exception {

	}
}
